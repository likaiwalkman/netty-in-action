package com.victor.client;

public class Constant {
    public static String LONG_STRING = "Thank you!\n" +
            "3Q！\n" +
            "Are you OK?\n" +
            "你还好吗？\n" +
            "Hello!\n" +
            "哈喽！\n" +
            "Thank you!\n" +
            "3Q！\n" +
            "Thank you very much!\n" +
            "3Q为麻吃！\n" +
            "Hello!\n" +
            "哈喽！\n" +
            "Thank you!\n" +
            "3Q！\n" +
            "Thank you very much!\n" +
            "3Q为麻吃！\n" +
            "He\n" +
            "哈\n" +
            "He Hello!\n" +
            "哈 哈喽！\n" +
            "Thank you!\n" +
            "3Q！\n" +
            "Thank you very much!\n" +
            "3Q为麻吃！\n" +
            "He\n" +
            "哈\n" +
            "HeHe\n" +
            "哈哈\n" +
            "Hello!\n" +
            "哈喽！\n" +
            "HeHe Hello!\n" +
            "哈哈 哈喽！\n" +
            "Thank you!\n" +
            "3Q！\n" +
            "Thank you very much!\n" +
            "3Q为麻吃！\n" +
            "How are you Indian Mi fans?\n" +
            "印度的米粉你们好吗？\n" +
            "Do you like Mi 4i?\n" +
            "你们喜欢小米4i吗？\n" +
            "OK Indian Mi fans\n" +
            "OK 印度的米粉们\n" +
            "Do you like Mi band?\n" +
            "你们喜欢小米手带吗？\n" +
            "We will give everyone\n" +
            "我们要给每个人\n" +
            "a free Mi band\n" +
            "一条免费的小米手带\n" +
            "and me(。·ω·。)\n" +
            "还有我！(脸红)\n" +
            "Mi fans!\n" +
            "米粉们！\n" +
            "Do you↗ like?↗\n" +
            "你们喜欢(我)吗？\n" +
            "I'm very happy to\n" +
            "我十分高兴\n" +
            "to be a(an) Indian\n" +
            "能成为一个印度人(误)\n" +
            "I'm very happy to\n" +
            "我十分高兴\n" +
            "to be a gift\n" +
            "能成为一个礼物（￣▽￣）\n" +
            "I‘m a free gift\n" +
            "我是一个免费的礼物\n" +
            "for every-everyone\n" +
            "送给每个每个人\n" +
            "Do you like me?(。·ω·。)\n" +
            "你们宣我嘛？（脸红）\n" +
            "Yeeeeeeeh！(/ ≥▽≤ )/\n" +
            "是哒！(/ ≥▽≤ )/\n" +
            "Thank you very much!\n" +
            "十分感谢！\n" +
            "Oh Indian Mi fans\n" +
            "噢 印度米粉们\n" +
            "\\ (゜∀゜)Are you OK？\n" +
            "你还好吧？\n" +
            "Are you OK？(゜∀゜)/\n" +
            "你还好吧？\n" +
            "Yeeeeeeeh！(/ ≥▽≤ )/\n" +
            "是哒！(/ ≥▽≤ )/\n" +
            "Oh everyone\n" +
            "噢 大家\n" +
            "Are you OK？(゜∀゜)/\n" +
            "你还好吧？\n" +
            "\\ (゜∀゜)Are you OK？\n" +
            "你还好吧？\n" +
            "I\n" +
            "我\n" +
            "I I I\n" +
            "我我我\n" +
            "I I I I I\n" +
            "我我我我我\n" +
            "I I I I I I I\n" +
            "我我我我我我我\n" +
            "I I I I I I mean\n" +
            "我我我我我 我是说\n" +
            "Are you OK？(゜∀゜)/\n" +
            "你还好吧？\n" +
            "Are you OK？(゜∀゜)/\n" +
            "你还好吧？\n" +
            "I’m very OK！\n" +
            "俺很好！\n" +
            "Oh Indian Mi fans\n" +
            "噢 印度米粉们\n" +
            "\\ (゜∀゜)Are you OK？\n" +
            "你还好吧？\n" +
            "Are you OK？(゜∀゜)/\n" +
            "你还好吧？\n" +
            "Oh China(Chinese) Mi Fans\n" +
            "噢 中国米粉\n" +
            "Are you OK？(゜∀゜)/\n" +
            "你还好吧？\n" +
            "\\ (゜∀゜)Are you OK？\n" +
            "你还好吧？\n" +
            "I\n" +
            "我\n" +
            "I I I\n" +
            "我我我\n" +
            "I I I I I I I\n" +
            "我我我我我我我\n" +
            "I I I I I I mean\n" +
            "我我我我我 我是说\n" +
            "How are you?\n" +
            "你好嘛？\n" +
            "I‘m fine thank you!\n" +
            "俺很好 谢谢！\n" +
            "Are you OK？(゜∀゜)/\n" +
            "你还好吧？\n" +
            "\\ (゜∀゜)Are you OK？\n" +
            "你还好吧？\n" +
            "We will give everyone a band\n" +
            "我们要给每个人一条手带\n" +
            "\\ (゜∀゜)Are you OK？\n" +
            "你还好吧？\n" +
            "We will give a band to everyone\n" +
            "(变换句型4分) 我们要把手带给每个人\n" +
            "\\ (゜∀゜)Are you OK？\n" +
            "你还好吧？\n" +
            "We will give a colour(ful) strap\n" +
            "我们要送一条彩色带子\n" +
            "All for free！\n" +
            "全免费！\n" +
            "I’m very happy\n" +
            "我十分嗨皮\n" +
            "ha happy!\n" +
            "嗨 嗨皮！\n" +
            "Oh Indian Mi fans\n" +
            "噢 印度米粉们\n" +
            "\\ (゜∀゜)Are you OK？\n" +
            "你还好吧？\n" +
            "Are you OK？(゜∀゜)/\n" +
            "你还好吧？\n" +
            "Yeeeeeeeh！(/ ≥▽≤ )/\n" +
            "是哒！(/ ≥▽≤ )/\n" +
            "Oh everyone\n" +
            "噢 大家\n" +
            "\\ (゜∀゜)Are you OK？\n" +
            "你还好吧？\n" +
            "Are you OK？(゜∀゜)/\n" +
            "你还好吧？\n" +
            "I\n" +
            "我\n" +
            "I I I\n" +
            "我我我\n" +
            "I I I I I\n" +
            "我我我我我\n" +
            "I I I I I I I\n" +
            "我我我我我我我\n" +
            "I I I I I I mean\n" +
            "我我我我我 我是说\n" +
            "Are you OK？(゜∀゜)/\n" +
            "你还好吧？\n" +
            "Are you OK？(゜∀゜)/\n" +
            "你还好吧？\n" +
            "I’m very OK！\n" +
            "俺很好！\n" +
            "Once again!\n" +
            "再来一次！\n" +
            "Oh Indian Mi fans\n" +
            "噢 印度米粉们\n" +
            "\\ (゜∀゜)Are you OK？\n" +
            "你还好吧？\n" +
            "Are you OK？(゜∀゜)/\n" +
            "你还好吧？\n" +
            "Oh China(Chinese) Mi Fans\n" +
            "噢 中国米粉\n" +
            "\\ (゜∀゜)Are you OK？\n" +
            "你还好吧？\n" +
            "Are you OK？(゜∀゜)/\n" +
            "你还好吧？\n" +
            "I\n" +
            "我\n" +
            "I I I\n" +
            "我我我\n" +
            "I I I I I\n" +
            "我我我我我\n" +
            "I I I I I I I\n" +
            "我我我我我我我\n" +
            "I I I I I I mean\n" +
            "我我我我我 我是说\n" +
            "How are you?\n" +
            "你好嘛？\n" +
            "I‘m fine thank you!\n" +
            "俺很好 谢谢！\n" +
            "Are you OK？(゜∀゜)/\n" +
            "你还好吧？";
}
